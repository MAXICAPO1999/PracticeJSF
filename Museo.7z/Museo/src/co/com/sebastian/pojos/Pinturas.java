package co.com.sebastian.pojos;

public class Pinturas {

}
