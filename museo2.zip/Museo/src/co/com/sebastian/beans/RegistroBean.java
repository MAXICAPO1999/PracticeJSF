package co.com.sebastian.beans;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import co.com.sebastian.conexion.*;
import co.com.sebastian.entities.Museo;

import org.hibernate.Session;

@ManagedBean(name="registro")
@SessionScoped
public class RegistroBean {
	
	private String nombre;
	private String direccion;
	private int telefono;
	
	public void guardar() {
		Session session = HibernateUtil.geSessionFactory().openSession();
		session.beginTransaction();
		Museo museo = new Museo(2,nombre, direccion, telefono);
		session.save(museo);
		session.getTransaction().commit();
		session.close();
	}
	
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getDireccion() {
		return direccion;
	}
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
	public int getTelefono() {
		return telefono;
	}
	public void setTelefono(int telefono) {
		this.telefono = telefono;
	}
}
