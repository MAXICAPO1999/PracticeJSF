package co.com.sebastian.pojos;

public class Museo {

}
