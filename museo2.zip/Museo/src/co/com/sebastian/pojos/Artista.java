package co.com.sebastian.pojos;

public class Artista {

}
